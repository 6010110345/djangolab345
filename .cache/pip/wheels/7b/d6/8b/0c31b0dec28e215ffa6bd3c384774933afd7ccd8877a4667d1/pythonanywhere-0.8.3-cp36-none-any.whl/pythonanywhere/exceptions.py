class SanityException(Exception):
    pass
